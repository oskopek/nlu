Skip-thoughts are from https://github.com/tensorflow/models/tree/master/research/skip_thoughts
