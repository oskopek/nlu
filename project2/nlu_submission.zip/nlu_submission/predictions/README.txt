pred_exp-Roemmele_Sentences_GRU_Rand6_test-stories.spring2016.csv ... predictions for the spring 2016 test set
pred_exp-Roemmele_Sentences_GRU_Rand6_test-stories.test.csv ... predictions for the ETH test set
